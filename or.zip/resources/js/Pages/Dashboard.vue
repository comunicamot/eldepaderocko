<template>
    <app-layout title="Dashboard">
        

      
            
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-5">
                    <p class="text-gray-600">
                        en desarrollo ....
                    </p>
                </div>
          
       
        
    </app-layout>
    
</template>

<script>
    import { defineComponent } from 'vue'
    import AppLayout from '@/Layouts/AppLayout.vue'


    export default defineComponent({
        components: {
            AppLayout,
            
        },
    })
</script>
