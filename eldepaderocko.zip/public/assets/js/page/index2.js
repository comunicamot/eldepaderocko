"use strict";

$(function () {
  $("#message-list")
    .css({
      height: 320
    })
    .niceScroll();

  $(".to-do-list")
    .css({
      height: 288
    })
    .niceScroll();
});
