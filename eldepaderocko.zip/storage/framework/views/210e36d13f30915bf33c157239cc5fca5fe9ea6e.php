<?php echo e($slot); ?>

<?php /**PATH /home/comunica/eldepaderocko.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>