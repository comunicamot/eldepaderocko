[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/comunica/eldepaderocko.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>