## About Laravel 7.3.x


## Install

Install commands:
``` 
- npm install
- composer update
- php >= 7.3
- php artisan migrate (crea las tablas)
- php artisan migrate:fresh --seed (pobla las tablas)
- php artisan serve (Inicia el server)
- npm run watch (Inicia el Vuejs)

