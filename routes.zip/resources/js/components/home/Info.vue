<template>
  <div class="flex flex-col md:flex-row justify-center  md:m-15">
    <div class="md:w-1/3 h-72">
      <img src="/image/estu.webp" class="h-full w-full" alt="" srcset="" />
    </div>
    <div class="md:w-1/2 text-left  md:h-72 flex bg-black items-center">
      <div class="p-4 px-9">
        <p class="hello ">¡Hola!</p>
        <p class="desc mt-5">
          Somos el primer portal inmobiliario Pet Friendly en el país.
          Actualmente contamos con ubicaciones en Punta Hermosa. Ofrecemos
          opciones de alquiler para familias junto a sus engreídos.
        </p>
        <p class="desc mt-5">Bienvenidos a la comunidad #RockoFriends.</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
.hello {
  /* font-family: "Raleway"; */
  font-style: normal;
  font-weight: 700;
  font-size: 50px;
  line-height: 59px;

  color: #ffffff;
}
.desc {
  /* font-family: "Raleway"; */
  font-style: normal;
  font-weight: 400;
  font-size: 22px;
  line-height: 26px;

  color: #ffffff;
}
</style>